DROP TRIGGER IF EXISTS ExercisePlanDifficulty;
