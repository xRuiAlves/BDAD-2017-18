DROP TRIGGER IF EXISTS ParticipationScore;
