.mode       columns
.headers    on
.nullvalue  NULL

-- Obtain all types of exercises in the application
SELECT name FROM ExerciseType;
